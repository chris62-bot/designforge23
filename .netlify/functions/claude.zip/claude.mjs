
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/claude.mjs
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
var claude_default = async (req) => {
  const apiKey = process.env.ANTHROPIC_API_KEY || process.env.API;
  if (req.method === "OPTIONS") {
    return new Response("", { status: 204, headers: CORS });
  }
  if (req.method !== "POST") {
    return json({ error: { message: "POST only" } }, 405);
  }
  if (!apiKey) {
    return json({ error: { message: "No API key found in env" } }, 500);
  }
  let body;
  try {
    body = await req.text();
  } catch (e) {
    return json({ error: { message: "Could not read request body" } }, 400);
  }
  try {
    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body
    });
    return new Response(upstream.body, {
      status: upstream.status,
      headers: {
        ...CORS,
        "Content-Type": upstream.headers.get("content-type") || "application/json",
        "Cache-Control": "no-cache"
      }
    });
  } catch (e) {
    return json({ error: { message: "Upstream request failed: " + e.message } }, 502);
  }
};
function json(obj, status) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" }
  });
}
var config = { path: "/api/claude" };
export {
  config,
  claude_default as default
};
